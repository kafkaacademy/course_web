package academy.kafka.serializers.examples;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;

public class JsonPerson {
    @JsonProperty(required = true)
    private String bsn;
    private String firstName;
    @JsonProperty(required = true)
    private String lastName;
    private String bancAccount;

    @JsonProperty(required = true)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate birthDay;
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
  
    private LocalDateTime timeStamp;

    public JsonPerson() {
    }

    public JsonPerson(String bsn, String firstName, String lastName, String bancAccount, LocalDate birthDay, LocalDateTime timestamp) {
        this.bsn = bsn;
        this.firstName = firstName;
        this.lastName = lastName;
        this.bancAccount = bancAccount;
        this.birthDay = birthDay;
        this.timeStamp= timestamp;
      }

    public String getBsn() {
        return bsn;
    }

    public void setBsn(String bsn) {
        this.bsn = bsn;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getBancAccount() {
        return bancAccount;
    }

    public void setBancAccount(String bancAccount) {
        this.bancAccount = bancAccount;
    }

    @Override
    public String toString() {
        return "Person [bancAccount=" + bancAccount + ", bsn=" + bsn + ", firstName=" + firstName + ", lastName="
                + lastName +"birthDay="+birthDay+ "]";
    }
}
