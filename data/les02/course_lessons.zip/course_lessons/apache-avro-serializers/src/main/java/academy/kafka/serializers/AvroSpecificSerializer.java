package academy.kafka.serializers;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Map;

import org.apache.avro.Schema;
import org.apache.avro.io.BinaryEncoder;
import org.apache.avro.io.DatumWriter;
import org.apache.avro.io.EncoderFactory;
import org.apache.avro.specific.SpecificDatumWriter;
import org.apache.avro.specific.SpecificRecord;
import org.apache.kafka.common.errors.SerializationException;
import org.apache.kafka.common.serialization.Serializer;

public class AvroSpecificSerializer<T extends SpecificRecord> implements Serializer<T> {

   // private Boolean isKey;
    private Schema schema;

    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {
   //     this.isKey = isKey;
        this.schema = (Schema) configs.get("schema");
    }

    @Override
    public byte[] serialize(String topic, T record) {
        if (record == null) {
            return null;
        }
        if (schema == null) {
            throw new SerializationException("deserializing error: configuration expects that \"schema\" is set");
        }
        try {
            return writeSpecificDataWithoutSchema(record);
        } catch (IOException e) {
            throw new SerializationException("Error when serializing SpecificRecordBase to byte[] for schema " + schema.getName());
        }
    }

    private byte[] writeSpecificDataWithoutSchema(T msg) throws IOException {
        DatumWriter<T> datumWriter = new SpecificDatumWriter<T>(schema);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        outputStream.reset();
        BinaryEncoder encoder = EncoderFactory.get().binaryEncoder(outputStream, null);
        datumWriter.write(msg, encoder);
        encoder.flush();
        outputStream.flush();
        return outputStream.toByteArray();
    }
}
