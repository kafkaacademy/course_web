package academy.kafka.entities;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.Iterator;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.kjetland.jackson.jsonSchema.annotations.JsonSchemaDescription;
import com.kjetland.jackson.jsonSchema.annotations.JsonSchemaInject;
import com.kjetland.jackson.jsonSchema.annotations.JsonSchemaString;
import com.kjetland.jackson.jsonSchema.annotations.JsonSchemaTitle;

import org.rocksdb.RocksDB;
import org.rocksdb.RocksDBException;

import academy.kafka.utils.KentekenGenerator;
import academy.kafka.utils.RocksDbUtils;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonSchemaInject(strings = { @JsonSchemaString(path = "$id", value = "academy.kafka.entity.Car") })
@JsonSchemaDescription(value = "The car as a taxable object")
@JsonSchemaTitle(value = "Car")
public class Car extends Entity {
  
    private String kenteken;
    private String make;
    private String model;
    private Integer tax;// yust to play with, on yearly basis

    public Car() {
    }

    public Car(String kenteken, String make, String model) {
        this.kenteken = kenteken;
        this.make = make;
        this.model = model;
        this.tax = 1200;
    }

    public String getKey(){
        return kenteken;
    }

    public String getKenteken() {
        return this.kenteken;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Integer getTax() {
        return tax;
    }

    public void setTax(Integer tax) {
        this.tax = tax;
    }
        
    @Override
    public String toString() {
        return String.format("Car [kenteken=%s, make= %s, model=%s, tax=%s]",getKenteken() ,make,model,tax);
    }

    
    /**************************************************************************************
     ************************** Utilities**************************************************
     *************************************************************************************/
    static public final String topicName = Car.class.getSimpleName();   

    public static Car fromJson(String jsonStr) {
        try {
            return JACKSON_MAPPER.readValue(jsonStr, Car.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    } 

    static String cars=
   "2020,Acura,ILX,[Sedan]"
+"2020,Acura,MDX,[SUV]"
+"2020,Acura,MDX Sport Hybrid,[SUV]"
+"2020,Acura,NSX,[Coupe]"
+"2020,Acura,RDX,[SUV]"
+"2020,Acura,RLX,[Sedan]"
+"2020,Acura,RLX Sport Hybrid,[Sedan]"
+"2020,Acura,TLX,[Sedan]"
+"2020,Alfa Romeo,4C Spider,[Convertible]"
+"2020,Alfa Romeo,Giulia,[Sedan]"
+"2020,Alfa Romeo,Stelvio,[SUV]"
+"2020,Audi,A3,[Sedan]"
+"2020,Audi,A4,[Sedan]"
+"2020,Audi,A5,[Coupe,Convertible,Sedan]"
+"2020,Audi,A6,[Sedan]"
+"2020,Audi,A6 allroad,[Wagon]"
+"2020,Audi,A7,[Sedan]"
+"2020,Audi,Q3,[SUV]"
+"2020,Audi,Q5,[SUV]"
+"2020,Audi,Q7,[SUV]"
+"2020,Audi,Q8,[SUV]"
+"2020,Audi,R8,[Coupe, Convertible]"
+"2020,Audi,S4,[Sedan]"
+"2020,Audi,S8,[Sedan]"
+"2020,Audi,SQ5,[SUV]"
+"2020,Audi,TT,[Coupe]"
+"2020,BMW,2 Series,[Coupe,Sedan,Convertible]"
+"2020,BMW,3 Series,[Sedan]"
+"2020,BMW,4 Series,[Sedan, Coupe, Convertible]"
+"2020,BMW,5 Series,[Sedan]"
+"2020,BMW,7 Series,[Sedan]"
+"2020,BMW,8 Series,[Coupe,Convertible,Sedan]"
+"2020,BMW,M2,[Coupe]"
+"2020,BMW,X1,[SUV]"
+"2020,BMW,X2,[SUV]"
+"2020,BMW,X3,[SUV]"
+"2020,BMW,X3 M,[SUV]"
+"2020,BMW,X4,[SUV]"
+"2020,BMW,X5,[SUV]"
+"2020,BMW,X6,[SUV]"
+"2020,BMW,X7,[SUV]"
+"2020,BMW,Z4,[Convertible]"
+"2020,Buick,Enclave,[SUV]"
+"2020,Buick,Encore,[SUV]"
+"2020,Buick,Encore GX,[SUV]"
+"2020,Buick,Envision,[SUV]"
+"2020,Buick,Regal Sportback,[Sedan]"
+"2020,Buick,Regal TourX,[Wagon]"
+"2020,Cadillac,CT4,[Sedan]"
+"2020,Cadillac,CT5,[Sedan]"
+"2020,Cadillac,CT6,[Sedan]"
+"2020,Cadillac,CT6-V,[Sedan]"
+"2020,Cadillac,Escalade,[SUV]"
+"2020,Cadillac,Escalade ESV,[SUV]"
+"2020,Cadillac,XT4,[SUV]"
+"2020,Cadillac,XT5,[SUV]"
+"2020,Cadillac,XT6,[SUV]"
+"2020,Chevrolet,Blazer,[SUV]"
+"2020,Chevrolet,Bolt EV,[Hatchback]"
+"2020,Chevrolet,Camaro,[Convertible, Coupe]"
+"2020,Chevrolet,Colorado Crew Cab,[Pickup]"
+"2020,Chevrolet,Colorado Extended Cab,[Pickup]"
+"2020,Chevrolet,Corvette,[Coupe, Convertible]"
+"2020,Chevrolet,Equinox,[SUV]"
+"2020,Chevrolet,Express 2500 Cargo,[Van/Minivan]"
+"2020,Chevrolet,Express 3500 Cargo,[Van/Minivan]"
+"2020,Chevrolet,Impala,[Sedan]"
+"2020,Chevrolet,Malibu,[Sedan]"
+"2020,Chevrolet,Silverado 1500 Crew Cab,[Pickup]"
+"2020,Chevrolet,Silverado 1500 Double Cab,[Pickup]"
+"2020,Chevrolet,Silverado 1500 Regular Cab,[Pickup]"
+"2020,Chevrolet,Silverado 2500 HD Crew Cab,[Pickup]"
+"2020,Chevrolet,Silverado 2500 HD Double Cab,[Pickup]"
+"2020,Chevrolet,Silverado 3500 HD Crew Cab,[Pickup]"
+"2020,Chevrolet,Sonic,[Sedan,Hatchback]"
+"2020,Chevrolet,Spark,[Hatchback]"
+"2020,Chevrolet,Suburban,[SUV]"
+"2020,Chevrolet,Tahoe,[SUV]"
+"2020,Chevrolet,Traverse,[SUV]"
+"2020,Chevrolet,Trax,[SUV]"
+"2020,Chrysler,300,[Sedan]"
+"2020,Chrysler,Pacifica,[Van/Minivan]"
+"2020,Chrysler,Pacifica Hybrid,[Van/Minivan]"
+"2020,Chrysler,Voyager,[Van/Minivan]"
+"2020,Dodge,Challenger,[Coupe]"
+"2020,Dodge,Charger,[Sedan]"
+"2020,Dodge,Durango,[SUV]"
+"2020,Dodge,Grand Caravan Passenger,[Van/Minivan]"
+"2020,Dodge,Journey,[SUV]"
+"2020,FIAT,124 Spider,[Convertible]"
+"2020,FIAT,500L,[Hatchback]"
+"2020,FIAT,500X,[SUV]"
+"2020,Ford,EcoSport,[SUV]"
+"2020,Ford,Edge,[SUV]"
+"2020,Ford,Escape,[SUV]"
+"2020,Ford,Expedition,[SUV]"
+"2020,Ford,Expedition MAX,[SUV]"
+"2020,Ford,Explorer,[SUV]"
+"2020,Ford,F150 Regular Cab,[Pickup]"
+"2020,Ford,F150 Super Cab,[Pickup]"
+"2020,Ford,F150 SuperCrew Cab,[Pickup]"
+"2020,Ford,F250 Super Duty Crew Cab,[Pickup]"
+"2020,Ford,F250 Super Duty Regular Cab,[Pickup]"
+"2020,Ford,F250 Super Duty Super Cab,[Pickup]"
+"2020,Ford,F350 Super Duty Crew Cab,[Pickup]"
+"2020,Ford,F350 Super Duty Super Cab,[Pickup]"
+"2020,Ford,F450 Super Duty Crew Cab,[Pickup]"
+"2020,Ford,Fusion,[Sedan]"
+"2020,Ford,Fusion Plug-in Hybrid,[Sedan]"
+"2020,Ford,Mustang,[Coupe, Convertible]"
+"2020,Ford,Ranger SuperCab,[Pickup]"
+"2020,Ford,Ranger SuperCrew,[Pickup]"
+"2020,Ford,Transit 250 Cargo Van,[Van/Minivan]"
+"2020,Ford,Transit 350 Passenger Van,[Van/Minivan]"
+"2020,Ford,Transit Connect Cargo Van,[Van/Minivan]"
+"2020,Ford,Transit Connect Passenger Wagon,[Van/Minivan]"
+"2020,Freightliner,Sprinter 1500 Cargo,[Van/Minivan]"
+"2020,Freightliner,Sprinter 1500 Passenger,[Van/Minivan]"
+"2020,Freightliner,Sprinter 2500 Cargo,[Van/Minivan]"
+"2020,Freightliner,Sprinter 2500 Crew,[Van/Minivan]"
+"2020,Freightliner,Sprinter 2500 Passenger,[Van/Minivan]"
+"2020,Freightliner,Sprinter 3500 Cargo,[Van/Minivan]"
+"2020,Freightliner,Sprinter 3500 Crew,[Van/Minivan]"
+"2020,Freightliner,Sprinter 3500 XD Crew,[Van/Minivan]"
+"2020,Freightliner,Sprinter 3500XD Cargo,[Van/Minivan]"
+"2020,Freightliner,Sprinter 4500 Cargo,[Van/Minivan]"
+"2020,Freightliner,Sprinter 4500 Crew,[Van/Minivan]"
+"2020,Genesis,G70,[Sedan]"
+"2020,Genesis,G80,[Sedan]"
+"2020,Genesis,G90,[Sedan]"
+"2020,GMC,Acadia,[SUV]"
+"2020,GMC,Canyon Crew Cab,[Pickup]"
+"2020,GMC,Sierra 1500 Crew Cab,[Pickup]"
+"2020,GMC,Sierra 1500 Double Cab,[Pickup]"
+"2020,GMC,Sierra 1500 Regular Cab,[Pickup]"
+"2020,GMC,Sierra 2500 HD Crew Cab,[Pickup]"
+"2020,GMC,Sierra 3500 HD Crew Cab,[Pickup]"
+"2020,GMC,Terrain,[SUV]"
+"2020,GMC,Yukon,[SUV]"
+"2020,GMC,Yukon XL,[SUV]"
+"2020,Honda,Accord,[Sedan]"
+"2020,Honda,Accord Hybrid,[Sedan]"
+"2020,Honda,Civic,[Hatchback, Coupe, Sedan]"
+"2020,Honda,Civic Type R,[Hatchback]"
+"2020,Honda,Clarity Fuel Cell,[Sedan]"
+"2020,Honda,Clarity Plug-in Hybrid,[Sedan]"
+"2020,Honda,CR-V,[SUV]"
+"2020,Honda,CR-V Hybrid,[SUV]"
+"2020,Honda,Fit,[Hatchback]"
+"2020,Honda,HR-V,[SUV]"
+"2020,Honda,Insight,[Sedan]"
+"2020,Honda,Odyssey,[Van/Minivan]"
+"2020,Honda,Passport,[SUV]"
+"2020,Honda,Pilot,[SUV]"
+"2020,Honda,Ridgeline,[Pickup]"
+"2020,Hyundai,Accent,[Sedan]"
+"2020,Hyundai,Elantra,[Sedan]"
+"2020,Hyundai,Elantra GT,[Hatchback]"
+"2020,Hyundai,Ioniq Electric,[Hatchback]"
+"2020,Hyundai,Ioniq Hybrid,[Hatchback]"
+"2020,Hyundai,Ioniq Plug-in Hybrid,[Hatchback]"
+"2020,Hyundai,Kona,[SUV]"
+"2020,Hyundai,Kona Electric,[SUV]"
+"2020,Hyundai,NEXO,[SUV]"
+"2020,Hyundai,Palisade,[SUV]"
+"2020,Hyundai,Santa Fe,[SUV]"
+"2020,Hyundai,Sonata,[Sedan]"
+"2020,Hyundai,Sonata Hybrid,[Sedan]"
+"2020,Hyundai,Tucson,[SUV]"
+"2020,Hyundai,Veloster,[Coupe]"
+"2020,Hyundai,Venue,[SUV]"
+"2020,INFINITI,Q50,[Sedan]"
+"2020,INFINITI,Q60,[Coupe]"
+"2020,INFINITI,QX50,[SUV]"
+"2020,INFINITI,QX60,[SUV]"
+"2020,INFINITI,QX80,[SUV]"
+"2020,Jaguar,E-PACE,[SUV]"
+"2020,Jaguar,F-PACE,[SUV]"
+"2020,Jaguar,F-TYPE,[Coupe, Convertible]"
+"2020,Jaguar,I-PACE,[SUV]"
+"2020,Jaguar,XE,[Sedan]"
+"2020,Jaguar,XF,[Sedan, Wagon]"
+"2020,Jeep,Cherokee,[SUV]"
+"2020,Jeep,Compass,[SUV]"
+"2020,Jeep,Gladiator,[Pickup]"
+"2020,Jeep,Grand Cherokee,[SUV]"
+"2020,Jeep,Renegade,[SUV]"
+"2020,Jeep,Wrangler,[SUV]"
+"2020,Jeep,Wrangler Unlimited,[SUV]"
+"2020,Kia,Cadenza,[Sedan]"
+"2020,Kia,Forte,[Sedan]"
+"2020,Kia,K900,[Sedan]"
+"2020,Kia,Niro,[Wagon]"
+"2020,Kia,Niro EV,[Wagon]"
+"2020,Kia,Niro Plug-in Hybrid,[Wagon]"
+"2020,Kia,Optima,[Sedan]"
+"2020,Kia,Optima Hybrid,[Sedan]"
+"2020,Kia,Optima Plug-in Hybrid,[Sedan]"
+"2020,Kia,Rio,[Sedan, Hatchback]"
+"2020,Kia,Sedona,[Van/Minivan]"
+"2020,Kia,Sorento,[SUV]"
+"2020,Kia,Soul,[Wagon]"
+"2020,Kia,Sportage,[SUV]"
+"2020,Kia,Stinger,[Sedan]"
+"2020,Kia,Telluride,[SUV]"
+"2020,Land Rover,Defender 110,[SUV]"
+"2020,Land Rover,Defender 90,[SUV]"
+"2020,Land Rover,Discovery,[SUV]"
+"2020,Land Rover,Discovery Sport,[SUV]"
+"2020,Land Rover,Range Rover,[SUV]"
+"2020,Land Rover,Range Rover Evoque,[SUV]"
+"2020,Land Rover,Range Rover Sport,[SUV]"
+"2020,Land Rover,Range Rover Velar,[SUV]"
+"2020,Lexus,ES,[Sedan]"
+"2020,Lexus,GS,[Sedan]"
+"2020,Lexus,GX,[SUV]"
+"2020,Lexus,IS,[Sedan]"
+"2020,Lexus,LC,[Coupe]"
+"2020,Lexus,LS,[Sedan]"
+"2020,Lexus,LX,[SUV]"
+"2020,Lexus,NX,[SUV]"
+"2020,Lexus,RC,[Coupe]"
+"2020,Lexus,RX,[SUV]"
+"2020,Lexus,UX,[SUV]"
+"2020,Lincoln,Aviator,[SUV]"
+"2020,Lincoln,Continental,[Sedan]"
+"2020,Lincoln,Corsair,[SUV]"
+"2020,Lincoln,MKZ,[Sedan]"
+"2020,Lincoln,Nautilus,[SUV]"
+"2020,Lincoln,Navigator,[SUV]"
+"2020,Lincoln,Navigator L,[SUV]"
+"2020,MAZDA,CX-3,[SUV]"
+"2020,MAZDA,CX-30,[SUV]"
+"2020,MAZDA,CX-5,[SUV]"
+"2020,MAZDA,CX-9,[SUV]"
+"2020,MAZDA,MAZDA3,[Sedan, Hatchback]"
+"2020,MAZDA,MAZDA6,[Sedan]"
+"2020,MAZDA,MX-5 Miata,[Convertible]"
+"2020,MAZDA,MX-5 Miata RF,[Convertible]"
+"2020,Mercedes-Benz,A-Class,[Sedan]"
+"2020,Mercedes-Benz,C-Class,[Sedan, Convertible, Coupe]"
+"2020,Mercedes-Benz,CLA,[Sedan]"
+"2020,Mercedes-Benz,CLS,[Sedan]"
+"2020,Mercedes-Benz,E-Class,[Sedan, Coupe, Wagon, Convertible]"
+"2020,Mercedes-Benz,G-Class,[SUV]"
+"2020,Mercedes-Benz,GLA,[SUV]"
+"2020,Mercedes-Benz,GLB,[SUV]"
+"2020,Mercedes-Benz,GLC,[SUV]"
+"2020,Mercedes-Benz,GLE,[SUV]"
+"2020,Mercedes-Benz,GLS,[SUV]"
+"2020,Mercedes-Benz,Mercedes-AMG A-Class,[Sedan]"
+"2020,Mercedes-Benz,Mercedes-AMG C-Class,[Sedan, Coupe, Convertible]"
+"2020,Mercedes-Benz,Mercedes-AMG CLS,[Sedan]"
+"2020,Mercedes-Benz,Mercedes-AMG GLC,[SUV]"
+"2020,Mercedes-Benz,Mercedes-AMG GLC Coupe,[SUV]"
+"2020,Mercedes-Benz,Metris WORKER Cargo,[Van/Minivan]"
+"2020,Mercedes-Benz,Metris WORKER Passenger,[Van/Minivan]"
+"2020,Mercedes-Benz,S-Class,[Sedan, Coupe, Convertible]"
+"2020,Mercedes-Benz,SLC,[Convertible]"
+"2020,Mercedes-Benz,Sprinter 1500 Cargo,[Van/Minivan]"
+"2020,Mercedes-Benz,Sprinter 1500 Passenger,[Van/Minivan]"
+"2020,Mercedes-Benz,Sprinter 2500 Cargo,[Van/Minivan]"
+"2020,Mercedes-Benz,Sprinter 2500 Crew,[Van/Minivan]"
+"2020,Mercedes-Benz,Sprinter 2500 Passenger,[Van/Minivan]"
+"2020,Mercedes-Benz,Sprinter 3500 Cargo,[Van/Minivan]"
+"2020,Mercedes-Benz,Sprinter 3500 Crew,[Van/Minivan]"
+"2020,Mercedes-Benz,Sprinter 3500 XD Cargo,[Van/Minivan]"
+"2020,Mercedes-Benz,Sprinter 3500 XD Crew,[Van/Minivan]"
+"2020,Mercedes-Benz,Sprinter 4500 Cargo,[Van/Minivan]"
+"2020,Mercedes-Benz,Sprinter 4500 Crew,[Van/Minivan]"
+"2020,MINI,Clubman,[Hatchback]"
+"2020,MINI,Countryman,[SUV]"
+"2020,MINI,Hardtop 2 Door,[Hatchback]"
+"2020,MINI,Hardtop 4 Door,[Hatchback]"
+"2020,Mitsubishi,Eclipse Cross,[SUV]"
+"2020,Mitsubishi,Mirage,[Hatchback]"
+"2020,Mitsubishi,Mirage G4,[Sedan]"
+"2020,Mitsubishi,Outlander,[SUV]"
+"2020,Mitsubishi,Outlander PHEV,[SUV]"
+"2020,Mitsubishi,Outlander Sport,[SUV]"
+"2020,Nissan,370Z,[Coupe]"
+"2020,Nissan,Altima,[Sedan]"
+"2020,Nissan,Armada,[SUV]"
+"2020,Nissan,Frontier Crew Cab,[Pickup]"
+"2020,Nissan,Frontier King Cab,[Pickup]"
+"2020,Nissan,GT-R,[Coupe]"
+"2020,Nissan,Kicks,[SUV]"
+"2020,Nissan,LEAF,[Hatchback]"
+"2020,Nissan,Maxima,[Sedan]"
+"2020,Nissan,Murano,[SUV]"
+"2020,Nissan,NV1500 Cargo,[Van/Minivan]"
+"2020,Nissan,NV200,[Van/Minivan]"
+"2020,Nissan,NV2500 HD Cargo,[Van/Minivan]"
+"2020,Nissan,NV3500 HD Cargo,[Van/Minivan]"
+"2020,Nissan,NV3500 HD Passenger,[Van/Minivan]"
+"2020,Nissan,Pathfinder,[SUV]"
+"2020,Nissan,Rogue,[SUV]"
+"2020,Nissan,Rogue Sport,[SUV]"
+"2020,Nissan,Sentra,[Sedan]"
+"2020,Nissan,Titan Crew Cab,[Pickup]"
+"2020,Nissan,Titan King Cab,[Pickup]"
+"2020,Nissan,TITAN XD Crew Cab,[Pickup]"
+"2020,Nissan,Versa,[Sedan]"
+"2020,Porsche,718 Boxster,[Convertible]"
+"2020,Porsche,718 Cayman,[Coupe]"
+"2020,Porsche,718 Spyder,[Convertible]"
+"2020,Porsche,911,[Convertible, Coupe]"
+"2020,Porsche,Cayenne,[SUV]"
+"2020,Porsche,Cayenne Coupe,[SUV]"
+"2020,Porsche,Macan,[SUV]"
+"2020,Porsche,Panamera,[Sedan]"
+"2020,Porsche,Taycan,[Sedan]"
+"2020,Ram,1500 Classic Crew Cab,[Pickup]"
+"2020,Ram,1500 Classic Quad Cab,[Pickup]"
+"2020,Ram,1500 Crew Cab,[Pickup]"
+"2020,Ram,1500 Quad Cab,[Pickup]"
+"2020,Ram,2500 Crew Cab,[Pickup]"
+"2020,Ram,3500 Crew Cab,[Pickup]"
+"2020,Ram,ProMaster Cargo Van,[Van/Minivan]"
+"2020,Ram,ProMaster City,[Van/Minivan]"
+"2020,Subaru,Ascent,[SUV]"
+"2020,Subaru,BRZ,[Coupe]"
+"2020,Subaru,Crosstrek,[SUV]"
+"2020,Subaru,Forester,[SUV]"
+"2020,Subaru,Impreza,[Wagon, Sedan]"
+"2020,Subaru,Legacy,[Sedan]"
+"2020,Subaru,Outback,[SUV]"
+"2020,Subaru,WRX,[Sedan]"
+"2020,Tesla,Model 3,[Sedan]"
+"2020,Tesla,Model S,[Sedan]"
+"2020,Tesla,Model X,[SUV]"
+"2020,Tesla,Model Y,[SUV]"
+"2020,Toyota,4Runner,[SUV]"
+"2020,Toyota,86,[Coupe]"
+"2020,Toyota,Avalon,[Sedan]"
+"2020,Toyota,Avalon Hybrid,[Sedan]"
+"2020,Toyota,Camry,[Sedan]"
+"2020,Toyota,Camry Hybrid,[Sedan]"
+"2020,Toyota,C-HR,[SUV]"
+"2020,Toyota,Corolla,[Sedan]"
+"2020,Toyota,Corolla Hatchback,[Hatchback]"
+"2020,Toyota,Corolla Hybrid,[Sedan]"
+"2020,Toyota,GR Supra,[Coupe]"
+"2020,Toyota,Highlander,[SUV]"
+"2020,Toyota,Highlander Hybrid,[SUV]"
+"2020,Toyota,Land Cruiser,[SUV]"
+"2020,Toyota,Mirai,[Sedan]"
+"2020,Toyota,Prius,[Hatchback]"
+"2020,Toyota,Prius Prime,[Hatchback]"
+"2020,Toyota,RAV4,[SUV]"
+"2020,Toyota,RAV4 Hybrid,[SUV]"
+"2020,Toyota,Sequoia,[SUV]"
+"2020,Toyota,Sienna,[Van/Minivan]"
+"2020,Toyota,Tacoma Access Cab,[Pickup]"
+"2020,Toyota,Tacoma Double Cab,[Pickup]"
+"2020,Toyota,Tundra CrewMax,[Pickup]"
+"2020,Toyota,Tundra Double Cab,[Pickup]"
+"2020,Toyota,Yaris,[Sedan]"
+"2020,Toyota,Yaris Hatchback,[Hatchback]"
+"2020,Volkswagen,Arteon,[Sedan]"
+"2020,Volkswagen,Atlas,[SUV]"
+"2020,Volkswagen,Atlas Cross Sport,[SUV]"
+"2020,Volkswagen,Golf,[Hatchback]"
+"2020,Volkswagen,Golf GTI,[Hatchback]"
+"2020,Volkswagen,Jetta,[Sedan]"
+"2020,Volkswagen,Jetta GLI,[Sedan]"
+"2020,Volkswagen,Passat,[Sedan]"
+"2020,Volkswagen,Tiguan,[SUV]"
+"2020,Volvo,S60,[Sedan]"
+"2020,Volvo,S90,[Sedan]"
+"2020,Volvo,V60,[Wagon]"
+"2020,Volvo,V90,[Wagon]"
+"2020,Volvo,XC40,[SUV]"
+"2020,Volvo,XC60,[SUV]"
+"2020,Volvo,XC90,[SUV]"
    ;
    public static Set<String> generateDatabase(int aantal) {
        Set<String> kentekens = KentekenGenerator.generateKentekenSet(aantal);
        Iterator<String> kentekenIterator = kentekens.iterator();
        RocksDB db = RocksDbUtils.newDatabase(Car.topicName);
       
             while (kentekenIterator.hasNext()) {
               try {
                   try (BufferedReader br = new BufferedReader(new StringReader(cars))) {
                        String line;
                        while ((line = br.readLine()) != null) {
                            String kenteken = kentekenIterator.next();
                            String[] values = line.split(",");
                            Car car = new Car(kenteken, values[1], values[2]);
                            db.put(kenteken.getBytes(), car.toJson().getBytes());
                            if (!kentekenIterator.hasNext())
                                break;
                        }
                    }
                } catch ( IOException | RocksDBException e) {
                    e.printStackTrace();
                }
            }
        
        db.close();
        return kentekens;
    }
}
