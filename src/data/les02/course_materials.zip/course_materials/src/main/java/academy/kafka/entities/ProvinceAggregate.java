package academy.kafka.entities;

public class ProvinceAggregate {
    String name;
    double total;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public ProvinceAggregate() {
    }

    public ProvinceAggregate(String name,double total) {
        this.name = name;
        this.total = total;
    }

    @Override
    public String toString() {
        return "ProvinceAggregate [name=" + name + ", total=" + total + "]";
    }
}
