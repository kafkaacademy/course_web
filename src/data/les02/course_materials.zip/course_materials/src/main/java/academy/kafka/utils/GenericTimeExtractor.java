package academy.kafka.utils;

import java.util.function.Function;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.streams.processor.TimestampExtractor;

public class GenericTimeExtractor<T> implements TimestampExtractor {
    private final Function<T,Long> extract;

    public GenericTimeExtractor(Function<T, Long> extract) {
        this.extract= extract;
    }

    @Override
    @SuppressWarnings("unchecked")
    public long extract(ConsumerRecord<Object, Object> consumerRecord, long prevTime) {        
        T record = (T) consumerRecord.value();
        if (record == null)
            return prevTime;
         long  eventTime=  extract.apply(record);
        return ((eventTime > 0) ? eventTime : prevTime);
    }
}