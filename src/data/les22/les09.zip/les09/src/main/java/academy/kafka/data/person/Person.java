package academy.kafka.data.person;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.javafaker.Faker;

import org.rocksdb.RocksDB;
import org.rocksdb.RocksDBException;

import academy.kafka.data.Utils;

import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;


@JsonInclude(JsonInclude.Include.NON_NULL) 
public class Person {

    private static final ObjectMapper JACKSON_MAPPER = new ObjectMapper();
    private static final SimpleDateFormat birthdayFormat = new SimpleDateFormat("yyyy-MM-dd");
    private static final Faker faker = new Faker(new Locale("nl"));
    private static final String cities[] = { "Amsterdam", "Rotterdam", "Utrecht", "Den Haag", "Leiden", "Eindhoven" };
    static {
        RocksDB.loadLibrary();
    }
    @JsonProperty(required = true)
    private String bsn;
    private String firstName;
    @JsonProperty(required = true)
    private String lastName;
    private String bancAccount;
    @JsonProperty(required = true)
    @JsonFormat
    (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private String birthday;
    @JsonProperty(required = true)
    private String city;

    public Person() {
    }

    public Person(String bsn, String firstName, String lastName, String bancAccount, String birthday, String city) {
        this.bsn = bsn;
        this.firstName = firstName;
        this.lastName = lastName;
        this.bancAccount = bancAccount;
        this.birthday = birthday;
        this.city = city;
    }

    public String getBsn() {
        return bsn;
    }

    public void setBsn(String bsn) {
        this.bsn = bsn;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getBancAccount() {
        return bancAccount;
    }

    public void setBancAccount(String bancAccount) {
        this.bancAccount = bancAccount;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @Override
    public String toString() {
        return "Person{" + "bsn=" + bsn + ", firstName=" + firstName + ", lastName=" + lastName + ", bancAccount="
                + bancAccount + ", birthday=" + birthday + ", city=" + city + '}';
    }

    public String toJson() {
        try {
            return JACKSON_MAPPER.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static Person fromJson(String jsonStr) {
        try {
            return JACKSON_MAPPER.readValue(jsonStr, Person.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    static public Person generatePerson(String bsn) {
        String firstName = faker.name().firstName();
        String lastName = faker.name().lastName();
        int randomNum = ThreadLocalRandom.current().nextInt(0, cities.length);
        String city = cities[randomNum];
        String birthDay = birthdayFormat.format(faker.date().birthday());
        String bancAccount = IbanGenerator.ibanGenerater();// faker.business().creditCardNumber();
        Person person = new Person(bsn, firstName, lastName, bancAccount, birthDay, city);
        return person;
    }

    static public String[] generatePersonsDatabase(int aantal) {

        Set<String> bsnSet = BsnGenerator.generateRandomBsnNummers(aantal);// first a unique list of bsn's
        RocksDB personDb = Utils.newDatabase("person");
        try {
            for (String bsn : bsnSet) {
                Person person = Person.generatePerson(bsn);
                personDb.put(person.getBsn().getBytes(), person.toJson().getBytes());
            }
        } catch (RocksDBException e) {
            e.printStackTrace();
        }
          personDb.close();
      
        return bsnSet.toArray(String[]::new);
    }

    public static void main(String[] args) {
        String[] bsnSet = generatePersonsDatabase(2000000);
        System.out.println(bsnSet.length);
    }

}
