package academy.kafka.data.registration;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.javafaker.Faker;

import org.rocksdb.RocksDB;
import org.rocksdb.RocksDBException;
import org.rocksdb.RocksIterator;

import academy.kafka.data.Utils;
import academy.kafka.data.cars.Car;
import academy.kafka.data.person.Person;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Registration {
    private static final Faker faker = new Faker(new Locale("nl"));

    private static final ObjectMapper JACKSON_MAPPER = new ObjectMapper();
    private static final SimpleDateFormat birthdayFormat = new SimpleDateFormat("yyyy-MM-dd");

    private UUID regId = UUID.randomUUID();

    private Car car;
    private Person person;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date from;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date till = null;

    public Registration() {

    }

    public Registration(Car car, Person person, Date from) {
        this.car = car;
        this.person = person;
        this.from = from;
    }

    /*
     * public Registration(Car car, Person person,Date from, Date till) { this.car =
     * car; this.person = person; this.from = birthdayFormat.format(from); this.till
     * = birthdayFormat.format(till); }
     */

    public UUID getRegId() {
        return regId;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public String getFrom() {
        return birthdayFormat.format(from);

    }

    public void setFrom(Date from) {
        this.from = from;
    }

    public String getTill() {
        if (this.till == null)
            return null;
        return birthdayFormat.format(till);
    }

    public void setTill(Date till) {

        this.till = till;

    }

    public String toJson() {
        try {
            return JACKSON_MAPPER.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static Registration fromJson(String jsonStr) {
        try {
            return JACKSON_MAPPER.readValue(jsonStr, Registration.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static Registration generate(Car car, Person person, Date from) {
        return new Registration(car, person, from);
    }

    private static Person getRandomPerson(int aantal, String bsns[], RocksDB personDb) {
        int randomBsnId = ThreadLocalRandom.current().nextInt(0, aantal);// 33% of cases
        String bsn = bsns[randomBsnId];
        byte[] bytes;
        try {
            bytes = personDb.get(bsn.getBytes());
            String json = new String(bytes);
            Person person = Person.fromJson(json);
            return person;
        } catch (RocksDBException e) {
            e.printStackTrace();
        }
        return null;
    }

    static void generateRegistrationDatabase(int aantal) {
        String[] bsns = Person.generatePersonsDatabase(aantal);
        Set<String> kentekens = Car.generateCarsDatabase(aantal);

        RocksDB personDb = Utils.openDatabase("person");
        RocksDB carDb = Utils.openDatabase("car");
        RocksDB regDb = Utils.newDatabase("registration");

        for (String kenteken : kentekens) {
            try {
                byte[] bytes = carDb.get(kenteken.getBytes());
                Car car = Car.fromJson(new String(bytes));

                Person person = getRandomPerson(aantal, bsns, personDb);

                Date from = faker.date().birthday(0, 12);
                Date now = new Date();
                Registration reg = Registration.generate(car, person, from);

                for (;;) {
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(now);
                    cal.add(Calendar.DATE, 3 * 365);
                    Date future = cal.getTime();
                    Date till = faker.date().between(from, future);
                    if (till.after(now)) {
                        String json = reg.toJson();
                        regDb.put(reg.regId.toString().getBytes(), json.getBytes());
                        break;
                    }
                    reg.setTill(till);
                    String json = reg.toJson();
                    regDb.put(reg.regId.toString().getBytes(), json.getBytes());

                    person = getRandomPerson(aantal, bsns, personDb);
                    reg = Registration.generate(car, person, till);

                }

            } catch (RocksDBException e) {
                e.printStackTrace();
            }
        }
        personDb.close();
        carDb.close();
        regDb.close();
    }

    public static void main(String[] args)
            throws FileNotFoundException, RocksDBException, IOException, URISyntaxException {
        generateRegistrationDatabase(10);
        RocksDB regDb = Utils.openDatabase("registration");
        RocksIterator iterator = regDb.newIterator();
        iterator.seekToFirst();
        while (iterator.isValid()) {
            byte[] value = iterator.value();
            String json = new String(value);
            Registration reg = Registration.fromJson(json);
            System.out.println(reg);
            iterator.next();
        }
        iterator.close();
        regDb.close();
    }

    @Override
    public String toString() {

        if (this.till == null) {
            return "Registration [car=" + car + ", from=" + this.getFrom() + ", person=" + person + "]";
        } else {
            return "Registration [car=" + car + ", from=" + this.getFrom() + ", till=" + this.getTill() + ", person="
                    + person + "]";
        }
    }

}
