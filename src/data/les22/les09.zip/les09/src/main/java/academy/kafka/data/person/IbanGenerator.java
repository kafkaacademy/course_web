package academy.kafka.data.person;

import java.util.Random;

public class IbanGenerator {
    
    public static String ibanGenerater()
  {
      String result="";
    Random rand = new Random();
    String card = "NL";
    for (int i = 0; i < 14; i++)
    {
        int n = rand.nextInt(10) + 0;
        card += Integer.toString(n);
    }
    for (int i = 0; i < 16; i++)
    {
        result+=card.charAt(i);
    }
    return result;
  }
}
