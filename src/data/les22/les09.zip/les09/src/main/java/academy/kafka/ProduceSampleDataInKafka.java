package academy.kafka;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.rocksdb.RocksDB;
import org.rocksdb.RocksIterator;

import academy.kafka.data.Utils;


public final class ProduceSampleDataInKafka {  
    
    static {
        RocksDB.loadLibrary();
    }

    public static int produce(String topic) {
        int counter=0;
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, org.apache.kafka.common.serialization.StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, org.apache.kafka.common.serialization.StringSerializer.class);
        Producer<String, String> producer = new KafkaProducer<>(props);
      
        RocksDB db=Utils.openDatabase(topic);
        RocksIterator it = db.newIterator();

        it.seekToFirst();
        while (it.isValid()) {   
            byte[] key = it.key();
            byte[] value = it.value();
            counter++;
             producer.send(new ProducerRecord<String, String>(topic,new String(key), new String(value)));
             System.out.println(String.format("%d send to kafka topic %s with key %s ",counter,topic,key));
             it.next();
        }
        producer.close();
        return counter;
    } 

    public static void main(String args[])  {
        int nrOfCars=produce("car");
        int nrOfPersons=produce("person");
        int nrOfRegistrations=produce("registration");
        System.out.println(String.format("%d cars, %d persons and %d registrations added to Apache Kafka",nrOfCars,nrOfPersons,nrOfRegistrations));
    }
}
