package academy.kafka.data.cars;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Iterator;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.rocksdb.RocksDB;
import org.rocksdb.RocksDBException;

import academy.kafka.data.Utils;


@JsonInclude(JsonInclude.Include.NON_NULL) 
public class Car {

    private static final ObjectMapper JACKSON_MAPPER = new ObjectMapper();

    private String kenteken;
    private String make;
    private String model;
    private Integer tax;// yust to play with, on yearly basis

    public Car() {
    }

    public Car(String kenteken, String make, String model) {
        this.kenteken = kenteken;
        this.make = make;
        this.model = model;
        this.tax = 1200;
    }

    public String getKenteken() {
        return this.kenteken;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Integer getTax() {
        return tax;
    }

    public void setTax(Integer tax) {
        this.tax = tax;
    }

    public String toJson() {
        try {
            return JACKSON_MAPPER.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public String toString() {
        return "Car [kenteken=" + getKenteken() + ", make=" + make + ", model=" + model + ", tax=" + tax + "]";
    }

    public static Car fromJson(String jsonStr) {
        try {
            return JACKSON_MAPPER.readValue(jsonStr, Car.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static Set<String> generateCarsDatabase(int aantal) {
        Set<String> kentekens = KentekenGenerator.generateKentekenSet(aantal);
        Iterator<String> kentekenIterator = kentekens.iterator();
        RocksDB carDb = Utils.newDatabase("car");
        URL resource = Car.class.getClassLoader().getResource("cars.csv");

        if (resource == null) {
            throw new IllegalArgumentException("file cars.cs not found!");
        } else {
            while (kentekenIterator.hasNext()) {
                File csvFile;
                try {
                    csvFile = new File(resource.toURI());
                    try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
                        String line;
                        while ((line = br.readLine()) != null) {
                            String kenteken = kentekenIterator.next();
                            String[] values = line.split(",");
                            Car car = new Car(kenteken, values[1], values[2]);
                            carDb.put(kenteken.getBytes(), car.toJson().getBytes());

                           


                            if (!kentekenIterator.hasNext())
                                break;
                        }
                    }
                } catch (URISyntaxException | IOException | RocksDBException e) {
                    e.printStackTrace();
                }

            }
        }
        carDb.close();
        return kentekens;
    }

    public static void main(String[] args) {
        Set<String> bsnSet = generateCarsDatabase(2000000);
        System.out.println(bsnSet.size());

    }

}
