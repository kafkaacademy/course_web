package academy.kafka.data;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.rocksdb.Options;
import org.rocksdb.RocksDB;
import org.rocksdb.RocksDBException;

public class Utils {

    static {
        RocksDB.loadLibrary();
    }

    static public RocksDB newDatabase(String name) {
        String tmpDir = System.getProperty("java.io.tmpdir");
        Path path = Paths.get(tmpDir, name + ".db");
        try {
            Options options = new Options();     
            RocksDB.destroyDB(path.toString(), options);
        } catch (RocksDBException e) {
           e.printStackTrace();
        }      
        return openDatabase(name);
    }

    static public RocksDB openDatabase(String name) {
        String tmpDir = System.getProperty("java.io.tmpdir");
        Path path = Paths.get(tmpDir, name + ".db");
        Options options = new Options();
        options.setCreateIfMissing(true);
        try {
            return RocksDB.open(options, path.toString());
        } catch (RocksDBException ex) {
            Logger.getLogger(Utils.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    /*
     * Generate cars from cars.csv file (see resources/cars.csv) public static int
     * generateCars(int aantal) throws RocksDBException, FileNotFoundException,
     * IOException, URISyntaxException { RocksDB carDb = newDatabase("car"); URL
     * resource =
     * GenerateDataForNextExercises.class.getClassLoader().getResource("cars.csv");
     * int teller = 0; if (resource == null) { throw new
     * IllegalArgumentException("file cars.cs not found!"); } else { for (int i = 0;
     * i < aantal; i++) { File csvFile = new File(resource.toURI()); try
     * (BufferedReader br = new BufferedReader(new FileReader(csvFile))) { String
     * line; while ((line = br.readLine()) != null) { String[] values =
     * line.split(","); Car car = new Car(values[1], values[2]);
     * carDb.put(car.getKenteken().getBytes(), car.toJson().getBytes()); teller++; }
     * } } } carDb.close(); return teller; }
     * 
     * 
     * public static void main(String args[]) throws RocksDBException, IOException,
     * FileNotFoundException, URISyntaxException {
     * 
     * int teller = generateCars(100); List<String> bsnSet =
     * BsnGenerator.generateRandomBsnNummers(teller);//enough bsn nummers int i = 0;
     * RocksDB personDb = openDatabase("person"); RocksDB carDb =
     * openDatabase("car"); RocksDB regDb = openDatabase("registration");
     * RocksIterator iterateCars = carDb.newIterator(); iterateCars.seekToFirst();
     * while (iterateCars.isValid()) { if (i>=(teller-1)) i=0;//continue till all
     * cars have an registration byte[] value = iterateCars.value();
     * iterateCars.next(); Car car = Car.fromJson(new String(value));
     * 
     * Person person = Person.generatePerson(bsnSet.get(i++));
     * personDb.put(person.getBsn().getBytes(), person.toJson().getBytes()); Date
     * from = faker.date().birthday(0, 12);//birthday car:) new till 12 years ago
     * Registration registration =Registration.generate(person, car, from);
     * regDb.put((person.getBsn() + car.getKenteken()).getBytes(),
     * registration.toJson().getBytes());
     * 
     * int randomNum = ThreadLocalRandom.current().nextInt(0, 2);//33% of cases a
     * person has more cars if (randomNum == 1) { Date till =
     * faker.date().birthday(0, 12); if (till.after(from)) { String tillStr =
     * birthdayFormat.format(till); registration.setTill(tillStr);
     * regDb.put((person.getBsn() + car.getKenteken()).getBytes(),
     * registration.toJson().getBytes());//overwrite
     * 
     * person = Person.generatePerson(bsnSet.get(i++)); registration =
     * Registration.generate(person, car, till); regDb.put((person.getBsn() +
     * car.getKenteken()).getBytes(), registration.toJson().getBytes()); } }
     * System.out.println("car "+i+" registered to a person"); }; carDb.close();
     * personDb.close(); regDb.close(); }
     */
}
