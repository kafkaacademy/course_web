# Step 1 : Apache Kafka with docker

[Video 1, install Apache Kafka using docker ](https://www.youtube.com/watch?v=4xFZ_iTZLTs&t=510s&ab_channel=BetterDataScience)

[Video 1, instructions ](https://betterdatascience.com/how-to-install-apache-kafka-using-docker-the-easy-way/)

Important to remember:

    docker exec -it kafka /bin/sh

    cd /opt/kafka/bin

    kafka-topics.sh --create --zookeeper zookeeper:2181 --replication-factor 1 --partitions 1 --topic first_kafka_topic

    kafka-topics.sh --list --zookeeper zookeeper:2181

--------------------------------------------------------------------

# Step 2 : Some basic Apache Kafka scripts


[Video 2, producers and consumers](https://www.youtube.com/watch?v=FlAlz8guJeM&ab_channel=BetterDataScience)

Prerequisite : docker running with apache kafka (wurstmeister image)

Open a console and type : 

    docker exec -it kafka /bin/sh

You should see 

    #

If you do not see this, restart docker-compose as in previous step
You are now in the running docker image, and go to the location where the scripts of Apache Kafka reside


    cd /opt/kafka/bin


Now we create a dummy topic, and because we have only one broker running in our cluster,  replication-factor is 1

    kafka-topics.sh --create --zookeeper zookeeper:2181 --replication-factor 1 --partitions 1 --topic dummy_topic

Note that we set partitions to 1, but that can be more. One broker can have multiple partitions for a topic

To verify which topics we have:

    kafka-topics.sh --list --zookeeper zookeeper:2181

To check the internals:

    kafka-topics.sh --describe --zookeeper zookeeper:2181 --topic dummy_topic 

To delete the topic:

    kafka-topics.sh --delete --zookeeper zookeeper:2181 --topic dummy_topic 


# Step 3 : producers and consumers with basic Apache Kafka scripts

[See previous video second part](https://youtu.be/FlAlz8guJeM?t=200)

Now we are creating producers and consumers
First we create our topic "messages"

    kafka-topics.sh --create --zookeeper zookeeper:2181 --replication-factor 1 --partitions 1 --topic messages

And then create a producer on this topic

    kafka-console-producer.sh --broker-list kafka:9092 --topic messages

Now you see

    >

This is a prompt , waiting for your inputs, you can enter here anything you want, with "enter" you produce one record


Now open another console

    docker exec -it kafka /bin/sh
    cd /opt/kafka/bin
    kafka-console-consumer.sh --bootstrap-server kafka:9092 --topic messages



You can type anything into the produder window like:

    {'user_id':1, 'name': 'Jan'}
    {'user_id':2, 'name': 'Marie'}


To see all messages from beginning , kill the consumer and start a new one:

    kafka-console-consumer.sh --bootstrap-server kafka:9092 --topic messages --from-beginning

# Step 3 (optional)  advanced  and recommended, use  keys 

With Apache Kafka topics it is recommended to use keys, most streaming applications are based on (key,value) records where keys are not null

    kafka-console-producer.sh  --broker-list localhost:9092 --topic messages  --property "parse.key=true"  --property "key.separator=:"

and enter data with separator ':': 

    key1:Peter
    key2:Ann 
    key3:John

# Step 4 : producers and consumers with Python

[Now using Python (full video)](https://www.youtube.com/watch?v=LHNtL4zDBuk&ab_channel=BetterDataScience)

[Idem but from the relevant part](https://youtu.be/LHNtL4zDBuk?t=169)

[See also the source code ](https://github.com/better-data-science/Apache-Kafka-in-Python)



Important:

Apache Kafka is made with java and scala (scala is based on java)
Accessing Apache Kafka using other languages than java is not recommended.
- most other lanuages calling Apache Kafka 
[Edenhill librdkafka](https://github.com/edenhill/librdkafka)

Although supported by Confluent it is another layer on top of Apache Kafka

[See Confluent](https://docs.confluent.io/5.5.0/clients/librdkafka/md_CONFIGURATION.html)

[Strong advice: Use streams with Apache Kafka's libraries](https://kafka.apache.org/documentation/streams/)

Install kafka-python

    python3 -m pip install kafka-python


We will generate data with generate_message.py


```
import random 
import string 

user_ids = list(range(1, 101))
recipient_ids = list(range(1, 101))

def generate_message() -> dict:
    random_user_id = random.choice(user_ids)

    # Copy the recipients array
    recipient_ids_copy = recipient_ids.copy()

    # User can't send message to himself
    recipient_ids_copy.remove(random_user_id)
    random_recipient_id = random.choice(recipient_ids_copy)

    # Generate a random message
    message = ''.join(random.choice(string.ascii_letters) for i in range(32))

    return {
        'user_id': random_user_id,
        'recipient_id': random_recipient_id,
        'message': message
    }

# testing
if __name__=='__main__':
    print (generate_message())
```

test the generation with

    python generate_message.py


and create a file producer.py 


```
import time 
import json 
import random 
from datetime import datetime
from data_generator import generate_message
from kafka import KafkaProducer


# Messages will be serialized as JSON 
def serializer(message):
    return json.dumps(message).encode('utf-8')


# Kafka Producer
producer = KafkaProducer(
    bootstrap_servers=['localhost:9092'],
    value_serializer=serializer
)


if __name__ == '__main__':
    # Infinite loop - runs until you kill the program
    while True:
        # Generate a message
        dummy_message = generate_message()
        
        # Send it to our 'messages' topic
        print(f'Producing message @ {datetime.now()} | Message = {str(dummy_message)}')
        producer.send('messages', dummy_message)
        
        # Sleep for a random number of seconds
        time_to_sleep = random.randint(1, 11)
        time.sleep(time_to_sleep)
```

start this file in a terminal with

    python producer.py


and now consumer.py

```
import json 
from kafka import KafkaConsumer

if __name__ == '__main__':
    consumer = KafkaConsumer('messages', bootstrap_servers='localhost:9092', auto_offset_reset='earliest' )
    for message in consumer:
        print(message.value)
```




and run in another terminal

    python consumer.py


