# Step 1 : Apache Kafka with docker

[Video 1, install Apache Kafka using docker ](https://www.youtube.com/watch?v=4xFZ_iTZLTs&t=510s&ab_channel=BetterDataScience)

[Video 1, instructions ](https://betterdatascience.com/how-to-install-apache-kafka-using-docker-the-easy-way/)

Important to remember:

    docker exec -it kafka /bin/sh

    cd /opt/kafka/bin

    kafka-topics.sh --create --zookeeper zookeeper:2181 --replication-factor 1 --partitions 1 --topic first_kafka_topic

    kafka-topics.sh --list --zookeeper zookeeper:2181

--------------------------------------------------------------------

# Step 2 : Some basic Apache Kafka scripts


[Video 2, producers and consumers](https://www.youtube.com/watch?v=FlAlz8guJeM&ab_channel=BetterDataScience)

Prerequisite : docker running with apache kafka (wurstmeister image)

Open a console and type : 

    docker exec -it kafka /bin/sh

You should see 

    #

If you do not see this, restart docker-compose as in previous step
You are now in the running docker image, and go to the location where the scripts of Apache Kafka reside


    cd /opt/kafka/bin


Now we create a dummy topic, and because we have only one broker running in our cluster,  replication-factor is 1

    kafka-topics.sh --create --zookeeper zookeeper:2181 --replication-factor 1 --partitions 1 --topic dummy_topic

Note that we set partitions to 1, but that can be more. One broker can have multiple partitions for a topic

To verify which topics we have:

    kafka-topics.sh --list --zookeeper zookeeper:2181

To check the internals:

    kafka-topics.sh --describe --zookeeper zookeeper:2181 --topic dummy_topic 

To delete the topic:

    kafka-topics.sh --delete --zookeeper zookeeper:2181 --topic dummy_topic 


# Step 3 : producers and consumers with basic Apache Kafka scripts

[See previous video second part](https://youtu.be/FlAlz8guJeM?t=200)

Now we are creating producers and consumers
First we create our topic "messages"

    kafka-topics.sh --create --zookeeper zookeeper:2181 --replication-factor 1 --partitions 1 --topic messages

And then create a producer on this topic

    kafka-console-producer.sh --broker-list kafka:9092 --topic messages

Now you see

    >

This is a prompt , waiting for your inputs, you can enter here anything you want, with "enter" you produce one record


Now open another console

    docker exec -it kafka /bin/sh
    cd /opt/kafka/bin
    kafka-console-consumer.sh --bootstrap-server kafka:9092 --topic messages



You can type anything into the produder window like:

    {'user_id':1, 'name': 'Jan'}
    {'user_id':2, 'name': 'Marie'}


To see all messages from beginning , kill the consumer and start a new one:

    kafka-console-consumer.sh --bootstrap-server kafka:9092 --topic messages --from-beginning

# Step 3 (optional)  advanced  and recommended, use  keys 

With Apache Kafka topics it is recommended to use keys, most streaming applications are based on (key,value) records where keys are not null

    kafka-console-producer.sh  --broker-list localhost:9092 --topic messages  --property "parse.key=true"  --property "key.separator=:"

and enter data with separator ':': 

    key1:Peter
    key2:Ann 
    key3:John

# Step 4 : producers and consumers with .net

Important:

Apache Kafka is made with java and scala (scala is based on java)
Accessing Apache Kafka using other languages than java is not recommended.
- most other lanuages calling Apache Kafka 
[Edenhill librdkafka](https://github.com/edenhill/librdkafka)

Although supported by Confluent it is another layer on top of Apache Kafka

[See Confluent](https://docs.confluent.io/5.5.0/clients/librdkafka/md_CONFIGURATION.html)

[Strong advice: Use streams with Apache Kafka's libraries](https://kafka.apache.org/documentation/streams/)


Copy the following into a file named producer.csproj:
```
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <TargetFramework>netcoreapp6.0</TargetFramework>
    <StartupObject>Producer</StartupObject>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="Confluent.Kafka" Version="1.8.2" />
    <PackageReference Include="Microsoft.Extensions.Configuration" Version="6.0.0" />
    <PackageReference Include="Microsoft.Extensions.Configuration.Binder" Version="6.0.0" />
    <PackageReference Include="Microsoft.Extensions.Configuration.Ini" Version="6.0.0" />
  </ItemGroup>

</Project>
```

Copy the following into a file named consumer.csproj
```
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <TargetFramework>netcoreapp6.0</TargetFramework>
    <StartupObject>Consumer</StartupObject>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="Confluent.Kafka" Version="1.8.2" />
    <PackageReference Include="Microsoft.Extensions.Configuration" Version="6.0.0" />
    <PackageReference Include="Microsoft.Extensions.Configuration.Binder" Version="6.0.0" />
    <PackageReference Include="Microsoft.Extensions.Configuration.Ini" Version="6.0.0" />
  </ItemGroup>

</Project>
```

Paste the following configuration data into a file at getting-started.properties

```
bootstrap.servers=localhost:9092
```
create a file producer.cs
```
using Confluent.Kafka;
using System;
using Microsoft.Extensions.Configuration;

class Producer {
    static void Main(string[] args)
    {
        if (args.Length != 1) {
            Console.WriteLine("Please provide the configuration file path as a command line argument");
        }

        IConfiguration configuration = new ConfigurationBuilder()
            .AddIniFile(args[0])
            .Build();

        const string topic = "purchases";

        string[] users = { "eabara", "jsmith", "sgarcia", "jbernard", "htanaka", "awalther" };
        string[] items = { "book", "alarm clock", "t-shirts", "gift card", "batteries" };

        using (var producer = new ProducerBuilder<string, string>(
            configuration.AsEnumerable()).Build())
        {
            var numProduced = 0;
            const int numMessages = 10;
            for (int i = 0; i < numMessages; ++i)
            {
                Random rnd = new Random();
                var user = users[rnd.Next(users.Length)];
                var item = items[rnd.Next(items.Length)];

                producer.Produce(topic, new Message<string, string> { Key = user, Value = item },
                    (deliveryReport) =>
                    {
                        if (deliveryReport.Error.Code != ErrorCode.NoError) {
                            Console.WriteLine($"Failed to deliver message: {deliveryReport.Error.Reason}");
                        }
                        else {
                            Console.WriteLine($"Produced event to topic {topic}: key = {user,-10} value = {item}");
                            numProduced += 1;
                        }
                    });
            }

            producer.Flush(TimeSpan.FromSeconds(10));
            Console.WriteLine($"{numProduced} messages were produced to topic {topic}");
        }
    }
}
```
Start this file with

	dotnet run --project producer.csproj %cd%/getting-started.properties


create a file consumer.cs
```
using Confluent.Kafka;
using System;
using System.Threading;
using Microsoft.Extensions.Configuration;

class Consumer
{

    static void Main(string[] args)
    {
        if (args.Length != 1)
        {
            Console.WriteLine("Please provide the configuration file path as a command line argument");
        }

        IConfiguration configuration = new ConfigurationBuilder()
            .AddIniFile(args[0])
            .Build();

        configuration["group.id"] = "kafka-dotnet-getting-started";
        configuration["auto.offset.reset"] = "earliest";

        const string topic = "purchases";

        CancellationTokenSource cts = new CancellationTokenSource();
        Console.CancelKeyPress += (_, e) => {
            e.Cancel = true; // prevent the process from terminating.
            cts.Cancel();
        };

        using (var consumer = new ConsumerBuilder<string, string>(
            configuration.AsEnumerable()).Build())
        {
            consumer.Subscribe(topic);
            try
            {
                while (true)
                {
                    var cr = consumer.Consume(cts.Token);
                    Console.WriteLine($"Consumed event from topic {topic} with key {cr.Message.Key,-10} and value {cr.Message.Value}");
                }
            }
            catch (OperationCanceledException)
            {
                // Ctrl-C was pressed.
            }
            finally
            {
                consumer.Close();
            }
        }
    }
}
```
and run

	dotnet run --project consumer.csproj %cd%/getting-started.properties